<?php 
$servername ="localhost";
$username = "root";
$password ="";
$db_name ="pariwisata";

$koneksi = mysqli_connect($servername, $username, $password, $db_name);

?>